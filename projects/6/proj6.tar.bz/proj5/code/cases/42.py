x = 12.0
print x
x = 34
print x
y = 23.5
print x*y
