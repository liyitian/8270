x = 6
y = 2
z = 50
x *= y
y /= 4.0
z //= x
print x
print y
print z
