x = 10
y = -3
z = 2
print x
print y
print z
print x + y + z
