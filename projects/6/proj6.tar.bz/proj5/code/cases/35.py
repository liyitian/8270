print -13*1*10
