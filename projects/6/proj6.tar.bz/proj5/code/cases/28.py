print -2-8
