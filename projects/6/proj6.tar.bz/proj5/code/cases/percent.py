print -3%5
