print -5
