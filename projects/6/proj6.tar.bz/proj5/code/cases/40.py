x = 34
y = 12
print x*y


