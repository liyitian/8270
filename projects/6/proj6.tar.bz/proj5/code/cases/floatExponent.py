print 3.2**4.1
print 2**(0.5)
print 2**(-0.5)
