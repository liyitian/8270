print -9%4
