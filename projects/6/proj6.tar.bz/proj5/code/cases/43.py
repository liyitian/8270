x = 54
y = 34.23
x += y
print x
y = 20
x*=y
print x
