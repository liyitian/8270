x = 51
x %= 8
print x
