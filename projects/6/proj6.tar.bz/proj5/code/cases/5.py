print -15-9**3
