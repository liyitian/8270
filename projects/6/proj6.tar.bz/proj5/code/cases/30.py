print 1-2*15+15
