print -6
