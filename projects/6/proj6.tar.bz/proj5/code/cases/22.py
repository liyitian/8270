print 7//1%6*4
