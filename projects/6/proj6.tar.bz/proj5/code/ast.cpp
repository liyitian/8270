// Companion source code for "flex & bison", published by O'Reilly
// helper functions for fb3-1
#  include <iostream>
#  include <stdlib.h>
#  include <math.h>
#  include <stdio.h>
#  include "ast.h"

double eval(AstNode *a) {
  double v = 0;
  switch( a->getNodetype() ) {
  case 'K': 
    if (a->getType()=='s') {
      std::cerr << "undefined number" <<std::endl;
    }
    v = a->getNumber(); break;
  case '+': 
    v = eval(a->getLeft()) + eval(a->getRight()); break;
  case '-': 
    v = eval(a->getLeft()) - eval(a->getRight()); break;
  case '*': 
    v = eval(a->getLeft()) * eval(a->getRight()); break;
  case '/': 
    if (eval(a->getRight())==0){
      std::cerr << "divide can not be zero!" <<std::endl;
      exit(0);
    }
    if (a->getType()=='i')
      v = floor(eval(a->getLeft())/eval(a->getRight()));
    else 
      v = eval(a->getLeft()) / eval(a->getRight()); break;
  case 'P': 
    v = pow( eval(a->getLeft()) , eval(a->getRight()) ); break;
  case 'S': 
    if (eval(a->getRight())==0){
      std::cerr << "divide can not be zero!" <<std::endl;
      exit(0);
    }
    v = floor(eval(a->getLeft())/eval(a->getRight()));break; 
  case '%':
    if (eval(a->getRight())==0){
      std::cerr << "divide can not be zero!" <<std::endl;
      exit(0);
    }
    v = (eval(a->getLeft())-eval(a->getRight())*floor(eval(a->getLeft())/eval(a->getRight())));
    break;
  case 'M': 
    v = -eval(a->getLeft()); break;
  default: std::cout << "internal error: bad node "
                << a->getNodetype() << std::endl;;
  }
  return v;
}

void treeFree(AstNode *a) {
  switch(a->getNodetype()) {
   // two subtrees
  case '+':
  case '-':
  case '*':
  case '/':
    treeFree(a->getRight());

   // one subtrees
  case 'M':
    treeFree(a->getLeft());

   //no subtree
  case 'K':
    delete a;
    break;

  default: std::cout << "internal error: bad node "
                << a->getNodetype() << std::endl;;
  }
}

