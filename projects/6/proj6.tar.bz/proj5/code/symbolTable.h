/*************************************************************************
	> File Name: symbolTable.h
	> Author:Yitian Li 
	> Mail: yitianl@g.clemson.edu
	> Created Time: Tue 22 Nov 2016 06:35:58 PM EST
 ************************************************************************/

#ifndef _SYMBOLTABLE_H
#define _SYMBOLTABLE_H

#include <unordered_map>
#include "ast.h"

class SymbolTable
{
public:
    static SymbolTable& getInstance(){
        static SymbolTable instance;
        return instance;
    }

    ~SymbolTable(){ 
        for(auto i: table)
            delete i.second;
    }

    void addSymbol(std::string str, AstNode* ast)
    {
        table[str] = ast;
    }

    AstNode* getAstNode(std::string str){
        if(table.count(str)==0) return NULL;
        return table[str]; 
    }

private:
    SymbolTable() {}
    SymbolTable(SymbolTable&) {}
    std::unordered_map<std::string, AstNode*> table;
};
#endif