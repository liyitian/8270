//  Declarations for an AST calculator
//  From "flex & bison", fb3-1, by John Levine
//  Adapted by Brian Malloy
#ifndef AST_H
#define AST_H

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
extern void yyerror(const char*);
extern void yyerror(const char*, const char);

class AstNode {
public:
  AstNode(char type, AstNode* l, AstNode* r) : nodetype(type), left(l), right(r) 
  {
    if (r!=nullptr){
      int flag = (AstNode::getLeft()->getType()=='d' || AstNode::getRight()->getType()=='d')?0:1;
      flag?AstNode::setType('i'):AstNode::setType('d');
    }
    else
    {
      int flag = (AstNode::getLeft()->getType()=='d')?0:1;
      flag?AstNode::setType('i'):AstNode::setType('d');
    
    }
  }
  AstNode(char type): nodetype(type) {}
  virtual ~AstNode() {}
  char getNodetype() const { return nodetype; }
  AstNode* getLeft() const  { return left; }
  AstNode* getRight() const { return right; }
  virtual double getNumber() const { throw std::string("No Number"); }
  virtual void setVal(double) { throw std::string("No Number To Be Set");}
  void setType(char ch) {
    datatype=ch;
  }
  char getType() const{return datatype;}
private:
  char nodetype;
  char datatype;
  AstNode *left;
  AstNode *right;
};

class AstNumber : public AstNode {
public:
  AstNumber(char datatype, double n) : AstNode('K'), number(n) 
  {
    AstNode::setType(datatype);
  } 
  void setVal(double num){number=num;}
  virtual ~AstNumber() {}
  virtual double getNumber() const { return number; }
private:
  double number;
};


double eval(AstNode*);   // Evaluate an AST
void treeFree(AstNode*); // delete and free an AST 

#endif
